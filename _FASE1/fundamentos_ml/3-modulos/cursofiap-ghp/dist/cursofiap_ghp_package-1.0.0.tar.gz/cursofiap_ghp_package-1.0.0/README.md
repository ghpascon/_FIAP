# Cursofiap-ghp

A simple example library.

## Installation

```sh
pip install cursofiap-ghp
```

## Usage

```python
from cursofiap-ghp import hello_world

print(hello_world())
```
