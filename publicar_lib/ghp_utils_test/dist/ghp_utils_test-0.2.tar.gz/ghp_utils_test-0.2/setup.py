from setuptools import setup, find_packages

setup(
    name="ghp_utils_test",
    version="0.2",
    packages=find_packages(),
    install_requires=[],  # Adicione aqui as depend�ncias, se houver
    author="ghpascon",
    description="Teste de upload de lib para o pypl",
    url="https://github.com/ghpascon/ghp_utils_test",  # Substitua com o link real
    license="MIT",
    )
