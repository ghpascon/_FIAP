def soma_lista(lista):
    return sum(lista)