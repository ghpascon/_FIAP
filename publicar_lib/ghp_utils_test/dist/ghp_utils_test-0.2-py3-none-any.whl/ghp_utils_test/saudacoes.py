def saudacao(nome):
    print(f'Seja bem vindo {nome}')